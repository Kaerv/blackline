<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Blackline_Checkout extends Module
{
    public function __construct() {
        $this->name = 'blackline_checkout';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Krystian Kordal';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Podsumowanie zamówienia blackline');
        $this->description = $this->l('Własny szablon potwierdzenia zamówienia');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install() {
        return parent::install();
    }

    public function uninstall() {
        return parent::uninstall();
    }
}